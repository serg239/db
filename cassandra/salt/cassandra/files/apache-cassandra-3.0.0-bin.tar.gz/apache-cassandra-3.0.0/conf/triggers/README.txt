Place triggers to be loaded in this directory, as jar files.
