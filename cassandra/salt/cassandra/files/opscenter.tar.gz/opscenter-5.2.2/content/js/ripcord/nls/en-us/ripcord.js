/**
@module ripcord/nls/en-us/ripcord
*/
define("ripcord/nls/en-us/ripcord", {});

// locale specific overrides go here, e.g.
// alertsNoActive: 'EN-US No active alert events. The cluster is operating within the configured thresholds for all alert metrics.'
//
// make sure to add e.g. 'en-us': true to the base phrase file if you add a new locale file
//# sourceMappingURL=ripcord.js.map
